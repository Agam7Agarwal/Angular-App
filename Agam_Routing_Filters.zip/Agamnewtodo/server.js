/**
 * Created by Agam on 5/3/2017.
 */
var express =require('express');
app = express();

app
    .use(express.static('app'))
    .listen(7000);