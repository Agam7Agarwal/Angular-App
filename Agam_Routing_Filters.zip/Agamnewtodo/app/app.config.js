/**
 * Created by Agam on 5/3/2017.
 */
var angular=require('angular');

app = angular.module('myapp',['ui.router']);

require('./scripts/Home/Controllers');
require('./scripts/aboutus/controllers');

require('./scripts/contactus/controllers');

app.config([
    '$locationProvider','$stateProvider','$urlRouterProvider',
    function ($locationProvider,$stateProvider,$urlRouterProvider) {
        $locationProvider.html5Mode({
            enabled:true,
            requireBase:false
        });

        $urlRouterProvider.when('/','/contactus/child1');


        $stateProvider.state('/sample',{
            url:'/HOME',
            templateUrl:'/scripts/Home/Views/tab2.html',
            controller:'homecontroller',
            controllerAs:'vm'
        });

        $stateProvider.state('/aboutus',{
            url:'/aboutus',
            templateUrl:'/scripts/aboutus/views/aboutus.html',
            controller:'aboutcontroller',
            controllerAs:'vm'
        });

        $stateProvider.state('/aboutus.child',{
           views:{
               'child':{
                   templateUrl:'/scripts/aboutus/views/child.html',
               }
           }
        });

        $stateProvider.state('/contactus',{
            url:'/contactus',
            templateUrl:'/scripts/contactus/views/contactus.html',
            controller:'contactuscontroller',
            controllerAs:'vm',
            abstract:true
        });

       $stateProvider.state('/contactus.child',{
           url:'/child1',
            views:{
                'left':{
                    templateUrl:'/scripts/contactus/views/left.html',
                },
                'right':{
                    templateUrl:'/scripts/contactus/views/right.html',
                },
                'center':{
                    templateUrl:'/scripts/contactus/views/center.html',
                }
            }

       });
    }
]);

