/**
 * Created by Agam on 5/11/2017.
 */
app.factory()