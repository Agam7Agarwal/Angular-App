/**
 * Created by Agam on 5/9/2017.
 */

app.controller('contactuscontroller', contactuscontroller);

function contactuscontroller() {
    var vm = this;
    vm.heading="This is Contact Us";

};