/**
 * Created by Agam on 5/9/2017.
 */
app.controller('aboutcontroller', function () {
    var vm = this;
    vm.heading="Custom Filter Exercise";
});

app.filter('prefixit',prefixit);
app.filter('capitalise',capitalise);

function prefixit() {
    return ( function (input) {
        if (!input) {
            return '';
        }
        else if(input%10 === 1 && input != "11")
        {
            return input + 'st';
        }
        else if(input%10 === 2  && input != "12"){
            return input + 'nd';
        }
        else if(input%10 === 3 && input != "13"){
            return input + 'rd';
        }
        else return input + 'th';
    })
}

function capitalise(){
    return ( function (input,index) {
        if(!input){
            return '';
        }
         var strbefore = input.substring(0,index-1);
         var str = input.substring(index-1);
         return strbefore + str.toUpperCase();
    })
}