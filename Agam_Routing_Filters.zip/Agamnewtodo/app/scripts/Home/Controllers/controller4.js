/**
 * Created by Agam on 5/5/2017.
 */
require('../service/service2.js');
require('../service/servicefilter.js');

app.controller('controller4', controller4);

controller4.$inject = ['servicefilter'];

function controller4(servicefilter) {
    var vm = this;
    /*servicefilter.getTodo().then(
        function (list) {*/
            vm.heading="Angular Routing";
           /* vm.pre=list.pre;
            vm.past=list.past;*/
       /* });*/
}