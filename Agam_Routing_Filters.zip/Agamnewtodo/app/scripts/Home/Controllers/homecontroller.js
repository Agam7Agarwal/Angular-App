/**
 * Created by Agam on 5/9/2017.
 */
app.controller('homecontroller', homecontroller);

homecontroller.$inject=['$state']

function homecontroller($state) {
    var vm = this;
    vm.data="This is Home";
    vm.name="Agam Agarwal";
    vm.goToState=function (where) {
        $state.go(where);
    }
}