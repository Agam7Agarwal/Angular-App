/**
 * Created by Agam on 5/5/2017.
 */
app.factory('todolist',gettodolist);

gettodolist.$inject =['$http'];

function gettodolist($http) {
    var factory = {};
    factory.getdata = getdata;
    return factory;

    function getdata() {
        return ( $http.get('scripts/Home/data.json')
                .then(function (response) {
                    return wrapup(response.data);
                })
        )
    }
}

    function wrapup(jsondata){

        return jsondata.map(function (item) {
           return new Todo(item);
        })
    }

    function Todo(item) {

        this.task = item.task;
        this.duedate = item.duedate;
        this.description = item.description;
        this.status = item.status;
    }


        Todo.prototype.hasCrossed = function () {
            return new Date(this.duedate) < new Date;
        }

        Todo.prototype.iscomplete = function () {
            var a=this.status;
            if(a==="pending")
            {
                return false;
            }
            else{
                return true;
            }
        }