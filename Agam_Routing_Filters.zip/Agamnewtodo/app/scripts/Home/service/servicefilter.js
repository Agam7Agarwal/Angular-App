
app.factory('servicefilter',filterdata);

filterdata.$inject = ['todolist'];

function filterdata(todolist) {
    var service = {};
    service.getTodo = getTodo;

    return service;

    function getTodo() {
        return todolist
            .getdata()
            .then(function (listtodo) {

                return getlist(listtodo);
            })
    }

    function getlist(listtodo) {
        var list = {
            "pre":{
                "complete":[],
                "incomplete":[]
            },
            "past":{
                "complete":[],
                "incomplete":[]
            }
        };

        listtodo.map(function (item) {
            if(item.hasCrossed()){
                if(item.iscomplete()){
                    list.pre.complete.push(item);
                }
                else {
                    list.pre.incomplete.push(item);
                }
            }
            else {
                if(item.iscomplete()) {
                    list.past.complete.push(item);
                }
                else{
                    list.past.incomplete.push(item);
                }
            }
        });
         return list;
    }

}